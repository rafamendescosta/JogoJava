import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.*;

public class JogoCowboy extends JFrame implements Runnable {
  Image[] img = new Image[8];
  Desenho des = new Desenho();
  final int FUNDO = 0;
  final int PARADO = 1;
  final int ANDA1 = 2;
  final int ANDA2 = 3;
  final int ANDA3 = 4;
  final int TIRO1 = 5;
  final int ANDAVERT1 = 6;
  final int ANDAVERT2 = 7;

  int posX1 = 10;
  int posY1 = getSize().height+img[PARADO].getHeight(this)+30;
  int posX2 = 850;
  int posY2 = getSize().height+img[PARADO].getHeight(this)+30;
  int estado = PARADO;
  int dir = 1;
  int dx = 0;

  boolean continua = true;
  public class Desenho extends JPanel {

    Desenho() {
      try {
        setPreferredSize(new Dimension(1000, 600)); // tamanho da tela
        img[FUNDO] = ImageIO.read(new File("fundo.jpg")); //background
        img[PARADO] = ImageIO.read(new File("parado.png"));
        img[ANDA1] = ImageIO.read(new File("anda1.png"));
        img[ANDA2] = ImageIO.read(new File("anda2.png"));
        img[ANDA3] = ImageIO.read(new File("anda3.png"));
        img[TIRO1] = ImageIO.read(new File("tiro1.png"));
        img[ANDAVERT1] = ImageIO.read(new File("anda1.png"));
        img[ANDAVERT2] = ImageIO.read(new File("anda1.png"));
      } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "A imagem não pode ser carregada!\n" + e, "Erro", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
      }
    }

    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.drawImage(img[FUNDO], 0, 0, getSize().width, getSize().height, this);
      g.drawImage(img[estado],dx+posX1,posY1 , dir*img[estado].getWidth(this), img[estado].getHeight(this), this); //desenha a imagem com tamanho da tela
       g.drawImage(img[estado],dx+posX2,posY2 , dir*img[estado].getWidth(this), img[estado].getHeight(this), this);
      Toolkit.getDefaultToolkit().sync(); //tipo um flush
    }
  }

  JogoCowboy() {
    super("Trabalho");
    new Thread(){
      public void run(){
        try{
          while(continua){
            switch(estado){
              case ANDA1:
              estado = ANDA2;
              posX1+=10*dir;
              break;
              case ANDA2:
              estado = ANDA3;
              posX1+=10*dir;
              break;
	      case ANDA3:


              break;
            }
            repaint();
            sleep(100);
          }


        }catch(InterruptedException ex){}
      }
    }.start();

    addKeyListener(new KeyAdapter(){
      public void keyPressed(KeyEvent e){
        switch (e.getKeyCode()) {
          case KeyEvent.VK_D:
          dx = 0;
          estado = ANDA1;
          dir = 1;
          break;
          case KeyEvent.VK_A:
          estado = ANDA1;
          dir = -1;
          dx = img[estado].getWidth(null);
          break;
          case KeyEvent.VK_SPACE:
          estado = TIRO1;
          repaint();
          break;
          case KeyEvent.VK_W:
          posY1-=10;
          estado = ANDAVERT1;
          repaint();
          break;
          case KeyEvent.VK_S:
          posY1+=10;
          estado = ANDAVERT2;
          repaint();
          break;
        }
      }
    });
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    add(des);
    pack();
    setVisible(true);
  }

  static public void main(String[] args) {
    JogoCowboy f = new JogoCowboy();
  }
}
