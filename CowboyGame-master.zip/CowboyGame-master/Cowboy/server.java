import java.net.*;
import java.io.*;
import java.util.Scanner;

class server{

  public static void main(String[] args) {
      ServerSocket ss = new ServerSocket(4999);
      Socket s = ss.accept();

      
  }
}
