import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.*;

public class ClienteFrame extends JFrame implements Runnable {

  static PrintStream os = null;
  JTextField textField;
  JTextArea textArea;
  JLabel lb;
  
  ClienteFrame() {
    super("Cliente do chat");
    add(lb = new JLabel("Player 1"));

    setSize(600,600);
    setVisible(true);

    addKeyListener(new KeyAdapter(){
      public void keyPressed(KeyEvent e){
        switch (e.getKeyCode()) {
          case KeyEvent.VK_W:
          os.println("W");
          break;

          case KeyEvent.VK_A:
          os.println("A");
          break;
          
          case KeyEvent.VK_SPACE:
          os.println("SP");
          break;

          case KeyEvent.VK_S:
          os.println("S");
          break;

          case KeyEvent.VK_D:
          os.println("D");
          break;
        }
      }
    });

  }

  public static void main(String[] args) {
    new Thread(new ClienteFrame()).start();
  }

  public void run() {
    Socket socket = null;
    Scanner is = null;

    try {
      socket = new Socket("127.0.0.1", 1025);
      os = new PrintStream(socket.getOutputStream(), true);
      is = new Scanner(socket.getInputStream());
    } catch (UnknownHostException e) {
      System.err.println("Don't know about host.");
    } catch (IOException e) {
      System.err.println("Couldn't get I/O for the connection to host");
    }

    try {
      String inputLine;

      do {
        lb.setText(inputLine=is.nextLine()+"\n");
      } while (!(is.nextLine()).equals("")); //

      os.close();
      is.close();
      socket.close();
    } catch (UnknownHostException e) {
      System.err.println("Trying to connect to unknown host: " + e);
    } catch (IOException e) {
      System.err.println("IOException:  " + e);
    }
  }
}
