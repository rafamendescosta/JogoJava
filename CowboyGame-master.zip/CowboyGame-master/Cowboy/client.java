import java.net.*;
import java.io.*;
import java.util.Scanner;

class client{

  public static void main(String[] args) {

      Socket s = new Socket("localhost",4999);
      


  }
}
